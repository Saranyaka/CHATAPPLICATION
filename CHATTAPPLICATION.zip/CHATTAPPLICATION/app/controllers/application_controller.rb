class ApplicationController < ActionController::Base



    def current_user
        #this helper gives name of the user who are logged in
        @current_user ||=User.find(session[:user_id]) if session[:user_id]
    

    end 

    def logged_in?
        #it gives the output as true or false


        !!current_user #boolean





    end  
    
    def require_user
        if !logged_in?
            redirect_to login_path
        end
    end            
end
