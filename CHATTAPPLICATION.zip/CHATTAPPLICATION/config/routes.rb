Rails.application.routes.draw do
  get 'sessions/new'
  get 'chatroom/create'
  root 'chatroom#create'

  get 'login', to: 'sessions#new'

  post 'login', to: 'sessions#create'

  post 'message', to: 'messages#create'



end 


